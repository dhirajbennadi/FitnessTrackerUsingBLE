/*
 * scheduler.c
 *
 *  Created on: Jan 28, 2022
 *  Author: Dhiraj Bennadi
 */
#include <stdbool.h>
#include "scheduler.h"
#include "app.h"
#include "em_core.h"
#include "i2c.h"
#include "sl_power_manager.h"
#include "ble.h"
#include "sl_bt_api.h"

#define INCLUDE_LOG_DEBUG 1
#include "src/log.h"

/*
 * This function returns the events set by the scheduler as per the priority
 *
 * Parameters: None
 *
 * Returns: uint32_t - Event to be processed
 */
// scheduler routine to return 1 event to main()code and clear that event
uint32_t getNextEvent(void)
{
 uint32_t theEvent = 0;
 uint32_t copyofEventVariable = 0;


 CORE_DECLARE_IRQ_STATE;
 // enter critical section
 CORE_ENTER_CRITICAL();
 // clear the event in your data structure, this has to be a read-modify-write
 copyofEventVariable = eventVariable;
 eventVariable = 0;
 // exit critical section
 CORE_EXIT_CRITICAL();

 /*Returning the event based on the priority*/
 /*The logic checks the number of bits needed to identify an event*/
// while(copyofEventVariable)
// {
//     bitSet = copyofEventVariable & 0x01;
//     bitCounter++;
//     if(bitSet)
//     {
//         break;
//     }
//     copyofEventVariable = copyofEventVariable >> 1;
// }


#ifdef LOGGING_ENABLE
 LOG_ERROR("Event Variable = %d\n\r", eventVariable);
#endif
 switch(copyofEventVariable)
 {
   case evtLETIMER0_UF:
     theEvent = evtLETIMER0_UF;
#ifdef LOGGING_ENABLE
     LOG_INFO("Underflow Interrupt Returned from Scheduler\n\r");
#endif
     break;

   case evtLETIMER0_COMP1:
     theEvent = evtLETIMER0_COMP1;
#ifdef LOGGING_ENABLE
     LOG_INFO("COMP1 Interrupt Returned from Scheduler\n\r");
#endif
     break;

   case evtI2C_Complete:
     theEvent = evtI2C_Complete;
#ifdef LOGGING_ENABLE
     LOG_INFO("I2C Interrupt Returned from Scheduler\n\r");
#endif
     break;

   case evtI2C_NACK:
     theEvent = evtI2C_NACK;
     break;

   default:
     theEvent = NO_EVENT;
     break;
 }

   return (theEvent);
} // getNextEvent()


/*
 * This function set a scheduler event - LETIMER
 *
 * Parameters: None
 *
 * Returns: None.
 */
// scheduler routine to set a scheduler event
void schedulerSetEvent_LETIMER(void)
{

  CORE_DECLARE_IRQ_STATE;
  // enter critical section
  CORE_ENTER_CRITICAL();
  // set the event in your data structure, this has to be a read-modify-write
  //eventVariable |= evtLETIMER0_UF;
  sl_bt_external_signal(evtLETIMER0_UF);
  // exit critical section
  CORE_EXIT_CRITICAL();
} // schedulerSetEvent_LETIMER()

/*
 * This function set a scheduler event - LETIMER
 *
 * Parameters: None
 *
 * Returns: None.
 */
void schedulerSetEvent_LETIMERCompare1(void)
{

  CORE_DECLARE_IRQ_STATE;
  // enter critical section
  CORE_ENTER_CRITICAL();
  // set the event in your data structure, this has to be a read-modify-write
  //eventVariable |= evtLETIMER0_COMP1;
  sl_bt_external_signal(evtLETIMER0_COMP1);
  // exit critical section
  CORE_EXIT_CRITICAL();
} // schedulerSetEvent_LETIMERCompare1()


/*
 * This function set a scheduler event - I2C Complete
 *
 * Parameters: None
 *
 * Returns: None.
 */
void schedulerSetEvent_I2CComplete(void)
{
  CORE_DECLARE_IRQ_STATE;
  // enter critical section
  CORE_ENTER_CRITICAL();
  // set the event in your data structure, this has to be a read-modify-write
  //eventVariable |= evtI2C_Complete;
  sl_bt_external_signal(evtI2C_Complete);
  // exit critical section
  CORE_EXIT_CRITICAL();
} //schedulerSetEvent_I2CComplete

void schedulerSetEvent_I2CNACK(void)
{
  CORE_DECLARE_IRQ_STATE;
  // enter critical section
  CORE_ENTER_CRITICAL();
  // set the event in your data structure, this has to be a read-modify-write
  //eventVariable |= evtI2C_Complete;
  sl_bt_external_signal(evtI2C_NACK);
  // exit critical section
  CORE_EXIT_CRITICAL();
} //schedulerSetEvent_I2CNACK

void schedulerSetEvent_GPIO_Even(void)
{
  CORE_DECLARE_IRQ_STATE;
  // enter critical section
  CORE_ENTER_CRITICAL();
  // set the event in your data structure, this has to be a read-modify-write
  //eventVariable |= evtI2C_Complete;
  sl_bt_external_signal(evtGPIO_PB0_IRQ);
  // exit critical section
  CORE_EXIT_CRITICAL();
}

void schedulerSetEvent_GPIO_Even_Odd(void)
{
  CORE_DECLARE_IRQ_STATE;
  // enter critical section
  CORE_ENTER_CRITICAL();
  // set the event in your data structure, this has to be a read-modify-write
  //eventVariable |= evtI2C_Complete;
  sl_bt_external_signal(evtGPIO_PB1_IRQ);
  // exit critical section
  CORE_EXIT_CRITICAL();
}

/*
 * This function handles the state machine for reading a temperature value from
 * Si 7021 through LETIMER and I2C Interrupts
 *
 * Parameters: None
 *
 * Returns: None.
 */
void TempStateMachine(sl_bt_msg_t *evt)
{
  static stateMachineStates currentState = Idle;
  uint32_t actualTempReading = 0;
  uint32_t event = 0;
  uint32_t currentEventType = 0;

  ble_data_struct_t *ble_DataPtr = getBleDataPtr();

  if(ble_DataPtr->connectionStatus == false)
  {
    return;
  }

  currentEventType = SL_BT_MSG_ID(evt->header);

  if(currentEventType == sl_bt_evt_system_external_signal_id)
  {
      event = evt->data.evt_system_external_signal.extsignals;
  }
  else
  {
    return;
  }

  switch(currentState)
  {
    case Idle:
      currentState = Idle;
      if(event == evtLETIMER0_UF)
      {
          enableTempSensor();
          timerWaitUs_irq(SI_7021_WAKE_UP_US);
          currentState = PowerOn7021;
      }
      break;

    case PowerOn7021:
      currentState = PowerOn7021;
      if(event == evtLETIMER0_COMP1)
      {
          sl_power_manager_add_em_requirement(SL_POWER_MANAGER_EM1);
          writeTempCommandIrq();
          currentState = I2CTempWriteCommand;
      }
      break;

    case I2CTempWriteCommand:
      currentState = I2CTempWriteCommand;
      if(event == evtI2C_Complete)
      {
          NVIC_DisableIRQ(I2C0_IRQn);
          sl_power_manager_remove_em_requirement(SL_POWER_MANAGER_EM1);
          timerWaitUs_irq(SI_7021_TEMP_CONVERSION_US);
          currentState = MeasurementInProgress;
      }
      else if(event == evtI2C_NACK)
      {
          /*If NACK repeat, resend the command*/
          writeTempCommandIrq();
          currentState = I2CTempWriteCommand;
      }
      break;

    case MeasurementInProgress:
      currentState = MeasurementInProgress;
      if(event == evtLETIMER0_COMP1)
      {
          sl_power_manager_add_em_requirement(SL_POWER_MANAGER_EM1);
          readTempCommandIrq();
          currentState = I2CTempReadCommand;
      }
      break;

    case I2CTempReadCommand:
      currentState = I2CTempReadCommand;
      if(event == evtI2C_Complete)
      {
          //disableTempSensor();
          sl_power_manager_remove_em_requirement(SL_POWER_MANAGER_EM1);
          actualTempReading = calculateActualTempFromRawValueIrq();
          updateTempValueInBleDatabase(actualTempReading);
          NVIC_DisableIRQ(I2C0_IRQn);
#ifdef LOGGING_ENABLE
          LOG_INFO("Timestamp = %d Temp Reading = %d\n\r",loggerGetTimestamp() , actualTempReading);
#endif
          currentState = Idle;
      }
      else if(event == evtI2C_NACK)
      {
          readTempCommandIrq();
          currentState = I2CTempReadCommand;
      }
      break;

    case numStates:
      /*Remove the warning*/
      break;

    default:
      /*Default Case*/
      break;

  }
}

void DiscoveryStateMachine(sl_bt_msg_t *evt)
{
  sl_status_t sc;
  static discoveryStateMachine currentState = DiscoveryServiceTemp;

  ble_data_struct_t *ble_DataPtr = getBleDataPtr();

  uint32_t currentEventType = SL_BT_MSG_ID(evt->header);

  switch(currentState)
  {
    case DiscoveryServiceTemp:
      currentState = DiscoveryServiceTemp;

      if(ble_DataPtr->bleClientEvent == client_connectionOpenedevt)
        {
          sc = sl_bt_gatt_discover_primary_services_by_uuid(ble_DataPtr->connectionStatus,
                                                            sizeof(thermo_service),
                                                            (const uint8_t * ) thermo_service);
          if(sc != SL_STATUS_OK)
            {
              LOG_INFO("BL:Stack Discover primary services error\n\r");
            }
          currentState = GATT_ServiceComplete_Temp;

        }


      break;

    case GATT_ServiceComplete_Temp:
      currentState = GATT_ServiceComplete_Temp;

      if(ble_DataPtr->bleClientEvent == client_gattProcedureCompletedevt)
        {
          sc = sl_bt_gatt_discover_characteristics_by_uuid(ble_DataPtr->connectionStatus,
                                                           ble_DataPtr->tempServiceHandle,
                                                           sizeof(thermo_char),
                                                           (const uint8_t * ) thermo_char);
          if(sc != SL_STATUS_OK)
            {
              LOG_INFO("BL:Stack GATT Discover Characteristics Error\n\r");
            }

          currentState = GATT_CharacteristicComplete_Temp;

        }

      break;

    case GATT_CharacteristicComplete_Temp:
      currentState = GATT_CharacteristicComplete_Temp;
      if(ble_DataPtr->bleClientEvent == client_gattProcedureCompletedevt)
        {
          sc = sl_bt_gatt_set_characteristic_notification(ble_DataPtr->connectionStatus,
                                                          ble_DataPtr->tempCharacteristicHandle,
                                                          sl_bt_gatt_indication);
          if(sc != SL_STATUS_OK)
            {
              LOG_INFO("BL:Stack GATT Set Characteristic Notification Error\n\r");
            }

          //currentState = GATT_CharacteristicConfirmation_Temp;
          currentState = DiscoveryServiceButton;
        }
      else if(ble_DataPtr->bleClientEvent == client_connectionClosedevt)
        {
          currentState = DiscoveryServiceTemp;
        }
      break;

      /*Confirmation is not a compulsory event to check*/
    case GATT_CharacteristicConfirmation:
      currentState = GATT_CharacteristicConfirmation;
      if(ble_DataPtr->bleClientEvent == client_characteristicValueIndication)
        {
//          sc = sl_bt_gatt_send_characteristic_confirmation(evt->data.evt_gatt_characteristic_value.connection);
//          if(sc != SL_STATUS_OK)
//            {
//              LOG_INFO("BL:Stack GATT Send Characteristic Confirmation Error\n\r");
//            }

          currentState = GATT_CharacteristicConfirmation;
        }
      break;

    case DiscoveryServiceButton:
      currentState = DiscoveryServiceButton;

      if(ble_DataPtr->bleClientEvent == client_gattProcedureCompletedevt)
        {
          sc = sl_bt_gatt_discover_primary_services_by_uuid(ble_DataPtr->connectionStatus,
                                                            sizeof(button_state_service_uuid.id),
                                                            (const uint8_t * ) button_state_service_uuid.id);
          if(sc != SL_STATUS_OK)
            {
              LOG_INFO("BL:Stack Discover primary services error\n\r");
            }
          currentState = GATT_ServiceComplete_Button;
        }
      break;

    case GATT_ServiceComplete_Button:
      currentState = GATT_ServiceComplete_Button;

      if(ble_DataPtr->bleClientEvent == client_gattProcedureCompletedevt)
        {

          // Discover button characteristic on the responder device
          sc = sl_bt_gatt_discover_characteristics_by_uuid(ble_DataPtr->connectionStatus,
                                                           ble_DataPtr->buttonServiceHandle,
                                                         sizeof(button_state_service_uuid.id),
                                                         (const uint8_t*)button_state_service_uuid.id);
          if(sc != SL_STATUS_OK)
            {
              LOG_INFO("BL:Stack GATT Discover Characteristics Error\n\r");
            }

          currentState = GATT_CharacteristicComplete_Button;
        }
      break;

    case GATT_CharacteristicComplete_Button:
      currentState = GATT_CharacteristicComplete_Button;

      if(ble_DataPtr->bleClientEvent == client_gattProcedureCompletedevt)
        {
          sc = sl_bt_gatt_set_characteristic_notification(ble_DataPtr->connectionStatus,
                                                          ble_DataPtr->buttonCharacteristicHandle,
                                                          sl_bt_gatt_indication);
          if(sc != SL_STATUS_OK)
            {
              LOG_INFO("BL:Stack GATT Set Characteristic Notification Error\n\r");
            }
          currentState = GATT_CharacteristicConfirmation;
        }
      break;


    default:
      break;
  }
  ble_DataPtr->bleClientEvent = noEvent;
}
