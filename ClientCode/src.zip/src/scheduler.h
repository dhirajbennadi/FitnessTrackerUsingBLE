/*
 * scheduler.h
 *
 *  Created on: Jan 28, 2022
 *  Author: Dhiraj Bennadi
 */

#ifndef SRC_SCHEDULER_H_
#define SRC_SCHEDULER_H_

#include <stdint.h>
#include "sl_bt_api.h"

typedef enum{
  NO_EVENT = 0,
  evtLETIMER0_UF = 1,
  evtLETIMER0_COMP1 = 2,
  evtI2C_Complete = 4,
  evtI2C_NACK = 8,
  evtGPIO_PB0_IRQ = 16,
  evtGPIO_PB1_IRQ = 32,
  numofEvents
}interruptEvents;

typedef enum{
  Idle = 0,
  PowerOn7021 = 1,
  I2CTempWriteCommand = 2,
  MeasurementInProgress = 3,
  I2CTempReadCommand = 4,
  numStates
}stateMachineStates;


/*Reference : Client Table Assignment 6*/
typedef enum{
  DiscoveryServiceTemp = 0,
  GATT_ServiceComplete_Temp = 1,
  GATT_CharacteristicComplete_Temp = 2,
  /*Common State for both button and temperature*/
  GATT_CharacteristicConfirmation = 3,
  DiscoveryServiceButton = 4,
  GATT_ServiceComplete_Button = 5,
  GATT_CharacteristicComplete_Button = 6,
  GATT_CharacteristicConfirmation_Button = 7,
  DiscoveryStateMachinenumStates
}discoveryStateMachine;

typedef enum {
  noEvent = 0,
  client_connectionOpenedevt = 1,
  client_gattProcedureCompletedevt = 2,
  client_characteristicValueIndication = 3,
  client_connectionClosedevt = 4
}clientEvents;
/*
 * This function returns the events set by the scheduler as per the priority
 *
 * Parameters: None
 *
 * Returns: uint32_t - Event to be processed
 */
uint32_t getNextEvent(void);

void schedulerSetEvent_LETIMER(void);
void schedulerSetEvent_LETIMERCompare1(void);
void schedulerSetEvent_I2CComplete(void);
void schedulerSetEvent_I2CNACK(void);
void schedulerSetEvent_GPIO_Even(void);


void TempStateMachine(sl_bt_msg_t *evt);
void DiscoveryStateMachine(sl_bt_msg_t *evt);

extern int eventVariable;
#endif /* SRC_SCHEDULER_H_ */
